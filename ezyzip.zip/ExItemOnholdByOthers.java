

public class ExItemOnholdByOthers extends Exception{
    public ExItemOnholdByOthers(){
        super("Item not available.");
    }

}
