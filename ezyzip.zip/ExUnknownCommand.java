

public class ExUnknownCommand extends Exception{
    public ExUnknownCommand(String message){
        super(message);
    }

}
