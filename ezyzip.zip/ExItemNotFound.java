

public class ExItemNotFound extends Exception{
    public ExItemNotFound(){
        super("Item not found.");
    }
}
