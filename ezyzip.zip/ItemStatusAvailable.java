public class ItemStatusAvailable implements ItemStatus {

    

    @Override
    public String getStatusandInfo(Item item) {
        return "Available";
    }

    @Override
    public String getStatus() {
        return "Available";
    }

    
    
    
}
