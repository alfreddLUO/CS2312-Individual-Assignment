

public class ExMemberIDNotFound extends Exception{
    public ExMemberIDNotFound(){
        super("Member not found.");
    }

}
