

public class ExItemRequestQuotaExceed extends Exception{
    public ExItemRequestQuotaExceed(){
        super("Item request quota exceeded.");
    }
}
