

public class ExRequestedRecordNotFound extends Exception{
    public ExRequestedRecordNotFound(){
        super("Request record is not found.");
    }

}
