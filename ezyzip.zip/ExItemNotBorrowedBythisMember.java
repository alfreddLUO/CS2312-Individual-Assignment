

public class ExItemNotBorrowedBythisMember extends Exception{
    public ExItemNotBorrowedBythisMember(){
        super("The item is not borrowed by this member.");
    }

}
