

public class ExQuotaLimitForEachPerson extends Exception{
    public ExQuotaLimitForEachPerson(){
        super("Loan quota exceeded.");
    }

}
