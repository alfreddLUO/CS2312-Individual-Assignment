public interface ItemStatus {
     public String getStatus();
     public String getStatusandInfo(Item item);
    }
