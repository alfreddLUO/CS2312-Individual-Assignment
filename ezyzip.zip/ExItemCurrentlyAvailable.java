

public class ExItemCurrentlyAvailable extends Exception{
    public ExItemCurrentlyAvailable(String message){
        super(message);
    }

}
