

public class ExItemBorrowedByOthers extends Exception{
    public ExItemBorrowedByOthers(){
        super("Item not available.");
    }
}
