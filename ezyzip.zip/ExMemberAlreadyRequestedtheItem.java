

public class ExMemberAlreadyRequestedtheItem extends Exception{
    public ExMemberAlreadyRequestedtheItem(){
        super("The same member has already requested the item.");
    }

}
